// serial.h - Header-Datei für die serielle Kommunikation
#ifndef SERIAL_H
#define SERIAL_H

void serialSetup();
void serialPrintMessage(const char* message);

#endif