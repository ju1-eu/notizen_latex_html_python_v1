// led.h - Header-Datei für die LED-Steuerung
#ifndef LED_H
#define LED_H

void ledSetup();
void ledBlink();

#endif